
import 'package:flutter/material.dart';

void main() {
  runApp(const InnovationHubApp());
}

class InnovationHubApp extends StatelessWidget {
  const InnovationHubApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Innovation Hub',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Innovation Hub'),
      ),
      body: const Center(
        child: Text('Welcome to Innovation Hub'),
      ),
    );
  }
}
